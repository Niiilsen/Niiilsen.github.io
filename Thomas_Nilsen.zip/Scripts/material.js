//Material object that each block has a unique instance of
function Material()
{
	this.color = vec4(1.0,1.0,1.0,1.0);
	this.ambient = vec4(0.1,0.1,0.3,1.0);
	this.shinyness = 100.0;
}